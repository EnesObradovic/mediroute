const { createClient } = require('@supabase/supabase-js');
const url = 'https://phdmnzsdyjhqoqiqwmho.supabase.co';
const key = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBoZG1uenNkeWpocW9xaXF3bWhvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzc1NzAzMzksImV4cCI6MjA5MzE0NjMzOX0.zUoYTYjp8Shva1iSVE0oW1ukGpiEOCghPiqc__WisPg';
const sb = createClient(url, key);

async function run() {
  console.log("Fetching leads...");
  const { data, error } = await sb.from('leads').select('*');
  if (error) console.error("Error fetching:", error);
  else console.log("Leads count:", data.length);
  
  if (data && data.length > 0) console.log(data[0]);
}
run();
