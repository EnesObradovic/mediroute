const { createClient } = require('@supabase/supabase-js');
const url = 'https://phdmnzsdyjhqoqiqwmho.supabase.co';
const key = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBoZG1uenNkeWpocW9xaXF3bWhvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzc1NzAzMzksImV4cCI6MjA5MzE0NjMzOX0.zUoYTYjp8Shva1iSVE0oW1ukGpiEOCghPiqc__WisPg';
const sb = createClient(url, key);

const mockClinics = [
  { name: 'SmileLine Antalya', city: 'Antalya', country: 'Turkey', price_min: 1200, price_max: 2500, rating: 4.9, reviews: 342, treatments: 'Dental Implants, Veneers, Teeth Whitening', description: 'Award winning dental clinic with cutting edge technology.', jci: 'yes', status: 'active', featured: true },
  { name: 'Estepera Medical', city: 'Istanbul', country: 'Turkey', price_min: 1500, price_max: 3000, rating: 4.8, reviews: 856, treatments: 'FUE Hair Transplant, DHI, PRP Therapy', description: 'World-renowned hair transplant clinic in the heart of Istanbul.', jci: 'yes', status: 'active', featured: true },
  { name: 'Dent Élite Budapest', city: 'Budapest', country: 'Hungary', price_min: 800, price_max: 2000, rating: 4.6, reviews: 215, treatments: 'Dental Implants, All-on-4', description: 'High quality affordable dental treatments in beautiful Budapest.', jci: 'no', status: 'active', featured: false },
  { name: 'VisionCare Praha', city: 'Prague', country: 'Czechia', price_min: 1000, price_max: 2500, rating: 4.7, reviews: 128, treatments: 'LASIK, Cataract Surgery', description: 'Leading eye care center in Central Europe.', jci: 'no', status: 'active', featured: false },
  { name: 'Slim & Health Antalya', city: 'Antalya', country: 'Turkey', price_min: 2500, price_max: 4500, rating: 4.8, reviews: 190, treatments: 'Gastric Sleeve, Gastric Bypass', description: 'Specialized bariatric surgery clinic.', jci: 'yes', status: 'active', featured: true }
];

async function run() {
  const { data: existing } = await sb.from('clinics').select('name');
  const existingNames = existing.map(c => c.name);
  const toInsert = mockClinics.filter(c => !existingNames.includes(c.name));
  
  if (toInsert.length > 0) {
    const { error } = await sb.from('clinics').insert(toInsert);
    if (error) console.error("Error seeding:", error);
    else console.log("Seeded", toInsert.length, "clinics!");
  } else {
    console.log("Clinics already seeded.");
  }
}
run();
